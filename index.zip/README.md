  **Nova** is a very basic website created for a school project.\
   It is a fictional brand that is a "steam-like" game store, but only with free products. The tech stack is nothing other than classic HTML, CSS (SASS), JS with PHP as the backend.
   
### Project guidelines (designated by the teacher)
  - Database: MySQL in phpMyAdmin
  - Documentation
  - Frontend: HTML, CSS
  - Must be responsive
  - Backend: PHP\
  Personally, I would use PostgreSQL for this, but unfortunately, we don't learn this technology at school, so I can't use it. I only learned PHP in school, not on my own like the rest, so I'm not sure how well and safely I'm using it. Nevertheless, the website is for demonstration purposes only, so I'm not concerned about security/optimization issues


