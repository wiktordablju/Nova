<!-- Personal notes, delete when ready -->

# TODO

    1. mixiny, remy
    2. Responsywnosc na telefony, tablety, sprawdzic wszystkie linki
    ---
    1. Rozplanowanie backendu
    2. Baza danych
    3. Backend - Logowanie, rejestracja, jesli zalogowany to w ustawieniach zamiast zaloguj to pokaz profil, wyloguj, usun konto, profil
    4. Sklep, biblioteka
    ---
    1. Przygotowac demo, dokumentacje


    ---
    1. ogarniecie kodu
    2. Zmiana jezykow jsem
